<?php
header('location:index.aspx');
?>